import requests
import boto3
import os
import sys

SNS_TOPIC_ARN = os.environ.get("SNS_TOPIC_ARN")
GOLD_API_KEY = os.environ.get("GOLD_API_KEY")

def get_gold_price():
    try:
        url = "https://www.goldapi.io/api/XAU/INR"

        headers = {
            "x-access-token": GOLD_API_KEY,
            "Content-Type": "application/json"
        }

        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            print("API Error:", response.text)
            sys.exit(1)

        data = response.json()
        price = data.get("price")

        if not price:
            print("Price not found:", data)
            sys.exit(1)

        return price

    except Exception as e:
        print("Error fetching gold price:", e)
        sys.exit(1)

def send_to_sns(price):
    try:
        sns = boto3.client('sns', region_name='ap-south-1')

        message = f"Gold Price (INR): {price}"

        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=message,
            Subject="Gold Price Alert"
        )

        print("Message sent to SNS")

    except Exception as e:
        print("Error sending to SNS:", e)
        sys.exit(1)

if __name__ == "__main__":
    price = get_gold_price()
    send_to_sns(price)