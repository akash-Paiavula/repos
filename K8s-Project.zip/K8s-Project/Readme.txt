docker build -t gold-image .

-----------TAG & PUSH IMAGE TO ECR:------------
aws ecr create-repository --repository-name gold-app, here you'll get the repository-uri

docker tag gold-image repository-uri

aws ecr get-login-password --region ap-south-1
| docker login --username AWS --password-stdin Acc_ID.dkr.ecr.ap-south-1.amazonaws.com

docker push repoUri

----------------------STEP 3: CREATE SNS TOPIC-------------------------

aws sns create-topic --name gold-price-topic

------------------STEP 4: SUBSCRIBE EMAIL------------------------

aws sns subscribe
--topic-arn <YOUR_TOPIC_ARN>
--protocol email
--notification-endpoint your-email@gmail.com

NOTE: Confirm the subscription from your email.

--------------------------STEP 5: CREATE EKS CLUSTER--------------------

eksctl create cluster
--name gold-cluster
--region ap-south-1
--nodes 2
--node-type t3.small

------------------------STEP 6: CONNECT TO CLUSTER-----------------------------

aws eks --region ap-south-1 update-kubeconfig --name gold-cluster

--------------------STEP 7: DEPLOY CRONJOB-----------------------------

cd ..

kubectl apply -f k8s/cronjob.yaml

---------------------------STEP 8: VERIFY CRONJOB---------------------------------

kubectl get cronjobs

---------------------------STEP 9: TRIGGER JOB MANUALLY------------------------

kubectl create job --from=cronjob/gold-cronjob test-job

------------------------------STEP 10: CHECK PODS---------------------------

kubectl get pods

-------------------------STEP 11: CHECK LOGS---------------------------

kubectl logs

Expected Output:
Message sent to SNS

--------------Cleanup-----------------------
eksctl delete cluster --name gold-cluster --region ap-south-1

Notes: In CronJob.yaml, Replace placeholders:
<YOUR_TOPIC_ARN>
<YOUR_GOLD_API_KEY>
<YOUR_ACCESS_KEY>
<YOUR_SECRET_KEY>